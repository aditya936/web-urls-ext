 # web-archive - Google Chrome Extension

# Installation
# # You can install  from the Chrome Web Store by following these simple steps
# 1- Go To extensions 
# 2- click Manage extensions
# 3- Load unpacked
